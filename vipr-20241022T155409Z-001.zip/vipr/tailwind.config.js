module.exports = {
  content: ['*'],
  theme: {
    extend: {
      fontFamily:{
        'paraFont': 'Work Sans',
        'haddingFont': 'Poppins',
        'dd':'pp'
      },
    },
  },
  plugins: [],
}
